namespace LevelUp.Domain.Enums;

public enum UserTokenType
{
    EmailConfirmation = 1,
    PasswordReset = 2
}
